<?php
$conexion= new mysqli("localhost","root","", "catalogo");
$conexion->set_charset("utf8");
?>