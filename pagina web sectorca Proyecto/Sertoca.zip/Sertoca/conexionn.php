<?php
$conexionn= new mysqli("localhost","root","", "catalogo");
$conexionn->set_charset("utf8");
?>